#include "util.h"

// config on new machine
// MPI config 
//1)C:\Program Files\MPICH2\include; % (AdditionalIncludeDirectories) C++

// OpenMP
// 2) enable openMP

//linker config 
// 3)C:\Program Files\MPICH2\lib\mpi.lib; % (AdditionalDependencies)
